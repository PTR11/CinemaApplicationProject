﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaApplicationProject.Model.Database
{
    public class MoviesStatistics : DatabaseBase
    {

        public int MovieId { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime Date { get; set; }

        public int AverageRating { get; set; }

        public int ViewersNumber { get; set; }


        public Movies Movie { get; set; }
    }
}
