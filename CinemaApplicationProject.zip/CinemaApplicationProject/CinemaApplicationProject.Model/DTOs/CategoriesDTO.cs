﻿using CinemaApplicationProject.Model.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CinemaApplicationProject.Model.DTOs
{
    public class CategoriesDTO : RespondDTO
    {

        public string Category { get; set; }

        public int MovieId { get; set; }

        public static explicit operator CategoriesDTO(Categories m) => new CategoriesDTO
        {
            Id = m.Id,
            Category = m.Category,
        };

        public static explicit operator Categories(CategoriesDTO m) => new Categories
        {
            Id = m.Id,
            Category = m.Category,
        };

    }
}
